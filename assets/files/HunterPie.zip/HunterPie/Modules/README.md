## Plugins

HunterPie supports simple 1-file plugins. For more information, read the [plugin documentation](https://hunterpie.me/HunterPie).